export declare const THEMEABLE: string[];
export declare const ALLOWED_VALUES: Record<string, string[]>;
export declare const RESERVED_SLOTS: Array<{ path: string; tokens: string[]; note: string }>;
export declare const CONTRAST_PAIRS: Array<{ fg: string; bg: string; min: number }>;
export declare function contrastRatio(hexA: string, hexB: string): number;

/**
 * The theme contract: the only tokens a project theme may change, and the
 * color pairs every theme must pass. The build refuses any theme that sets a
 * token outside THEMEABLE or fails a CONTRAST_PAIRS check.
 *
 * To let themes change something new, add its path prefix here and get design
 * sign-off first: every token added makes fidelity harder to protect.
 */

/** Token path prefixes a theme may override. Everything else is fixed. */
export const THEMEABLE = [
  'color.primary',
  'color.secondary',
  'color.text',
  'color.bg',
  'color.border',
  'color.button',
  'color.chart',
  'font.family',
  'font.weight',
  'font.stem',
  'font.cap-height',
  'font.x-height',
  'radius.button',
  'radius.field',
  'radius.checkbox',
  'radius.list',
  'radius.card',
  'radius.sheet',
  'shape.button',
  'hover.border-fill',
];

/**
 * The only values a theme may give these tokens (as resolved CSS values):
 * corner radii are 0 (square), 4, 8 or 12px; pill is allowed for buttons only;
 * checkboxes are 4px or square; card images are 0, 8, 12, 16 or 24px; sheets are 32px or square; hover borders are kept (0) or take the fill (1).
 */
export const ALLOWED_VALUES = {
  'radius.button': ['0', '0.25rem', '0.5rem', '0.75rem', '9999px'],
  'radius.field': ['0', '0.25rem', '0.5rem', '0.75rem'],
  'radius.checkbox': ['0', '0.25rem'],
  'radius.list': ['0', '0.5rem', '0.75rem', '1rem'],
  'radius.card': ['0', '0.5rem', '0.75rem', '1rem', '1.5rem'],
  'radius.sheet': ['0', '2rem'],
  'hover.border-fill': ['0', '1'],
};

/**
 * Slots listed in the docs with no default value. Themes may fill them; until
 * then no CSS variable exists, so components cannot depend on them.
 */
export const RESERVED_SLOTS = [
  {
    path: 'color.secondary',
    tokens: ['light', 'base', 'dark', 'foreground'],
    note: 'Reserved for a NYCO secondary color. Not set yet.',
  },
];

/**
 * Foreground/background pairs checked in every theme.
 * min: 4.5 for text, 3 for control borders, focus rings and large text (WCAG 2.2 AA).
 * A pair where neither token exists (an unfilled reserved slot) is skipped.
 */
export const CONTRAST_PAIRS = [
  { fg: 'color.text.primary', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.bg.secondary', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.bg.secondary-hover', min: 4.5 },
  { fg: 'color.bg.primary', bg: 'color.border.strong', min: 4.5 },
  { fg: 'color.text.secondary', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.text.description', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.text.description', bg: 'color.bg.secondary', min: 4.5 },
  { fg: 'color.text.link', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.text.link-hover', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.border.control', bg: 'color.bg.primary', min: 3 },
  { fg: 'color.border.focus', bg: 'color.bg.primary', min: 3 },
  { fg: 'color.border.error', bg: 'color.bg.primary', min: 3 },
  { fg: 'color.button.primary.text', bg: 'color.button.primary.base', min: 4.5 },
  { fg: 'color.button.primary.text', bg: 'color.button.primary.hover', min: 4.5 },
  { fg: 'color.button.secondary.text', bg: 'color.button.secondary.base', min: 4.5 },
  { fg: 'color.button.secondary.text', bg: 'color.button.secondary.hover', min: 4.5 },
  { fg: 'color.button.neutral.text', bg: 'color.button.neutral.base', min: 4.5 },
  { fg: 'color.button.neutral.text', bg: 'color.button.neutral.hover', min: 4.5 },
  { fg: 'color.primary.foreground', bg: 'color.primary.base', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.primary.subtle', min: 4.5 },
  { fg: 'color.border.focus', bg: 'color.primary.subtle', min: 3 },
  { fg: 'color.secondary.foreground', bg: 'color.secondary.base', min: 4.5 },
  { fg: 'color.info.dark', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.success.dark', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.warning.dark', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.error.dark', bg: 'color.bg.primary', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.info.light', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.success.light', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.warning.light', min: 4.5 },
  { fg: 'color.text.primary', bg: 'color.error.light', min: 4.5 },
  { fg: 'color.info.dark', bg: 'color.info.light', min: 3 },
  { fg: 'color.success.dark', bg: 'color.success.light', min: 3 },
  { fg: 'color.warning.dark', bg: 'color.warning.light', min: 3 },
  { fg: 'color.error.dark', bg: 'color.error.light', min: 3 },
  { fg: 'color.text.link', bg: 'color.info.light', min: 4.5 },
  { fg: 'color.text.link', bg: 'color.success.light', min: 4.5 },
  { fg: 'color.text.link', bg: 'color.warning.light', min: 4.5 },
  { fg: 'color.text.link', bg: 'color.error.light', min: 4.5 },
];

/** WCAG 2.x contrast ratio between two 6-digit hex colors. */
export function contrastRatio(hexA, hexB) {
  const [lighter, darker] = [luminance(hexA), luminance(hexB)].sort((a, b) => b - a);
  return (lighter + 0.05) / (darker + 0.05);
}

function luminance(hex) {
  const channels = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255);
  const [r, g, b] = channels.map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
